echo " Enter any two number"
read a
read b
c=$(($a + $b))
d=$(($a - $b))
e=$(($a * $b))
f=$(( $a / $b))
echo " addition of $a anb $b is :"$c
echo " substraction of $a and $b is :"$d
echo " multiplication ot $a and $b is :"$e
echo " division of $a and $b is :"$f
